"use client";

import { useEffect, useState } from "react";
import { Loader2, CheckCircle2, AlertTriangle, XCircle } from "lucide-react";
import { useWizardStore } from "@/store/wizard-store";

export function AutoSaveIndicator() {
  const status = useWizardStore((s) => s.autoSaveStatus);
  const lastSavedAt = useWizardStore((s) => s.lastSavedAt);
  const [secondsAgo, setSecondsAgo] = useState<number | null>(null);

  useEffect(() => {
    if (!lastSavedAt) return;

    const update = () => {
      setSecondsAgo(Math.floor((Date.now() - new Date(lastSavedAt).getTime()) / 1000));
    };

    update();
    const interval = setInterval(update, 1000);
    return () => clearInterval(interval);
  }, [lastSavedAt]);

  if (status === "saving") {
    return (
      <div className="flex items-center gap-1.5 text-[#0052CC]">
        <Loader2 className="h-4 w-4 animate-spin text-[#0052CC]" />
        <span className="text-xs font-medium text-[#0052CC]">جاري الحفظ...</span>
      </div>
    );
  }

  if (status === "saved") {
    return (
      <div className="flex items-center gap-1.5 text-emerald-700">
        <CheckCircle2 className="h-4 w-4" />
        <span className="text-xs font-medium">
          {secondsAgo !== null ? `تم الحفظ منذ ${secondsAgo} ثانية` : "تم الحفظ"}
        </span>
      </div>
    );
  }

  if (status === "conflict") {
    return (
      <div className="flex items-center gap-1.5 text-amber-600">
        <AlertTriangle className="h-4 w-4" />
        <span className="text-xs font-medium">تم تعديل هذه المسودة من مستخدم آخر</span>
      </div>
    );
  }

  if (status === "error") {
    return (
      <div className="flex items-center gap-1.5 text-red-600">
        <XCircle className="h-4 w-4" />
        <span className="text-xs font-medium">خطأ في الحفظ</span>
      </div>
    );
  }

  return null;
}